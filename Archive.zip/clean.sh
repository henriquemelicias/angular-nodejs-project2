rm -r ./frontend/node_modules
rm -r ./backend/node_modules
rm -r ./frontend/.angular
