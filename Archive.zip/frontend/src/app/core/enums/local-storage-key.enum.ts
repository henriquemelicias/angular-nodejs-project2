export enum LocalStorageKeyEnum {
  AUTH_TOKEN = "auth-token",
  AUTH_USER = "auth-user",
  REGISTER_FORM = "register-form-values",
  PROJECT_FORM = "project-form-values"
}
