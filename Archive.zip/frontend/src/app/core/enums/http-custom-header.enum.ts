export enum HttpCustomHeaderEnum {
  CsrfToken = 'X-Csrf-Token',
  AuthorizationRole = 'X-Auth-Role'
}
