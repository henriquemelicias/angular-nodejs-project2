export enum HttpCustomHeaderEnum {
  CsrfToken = 'x-csrf-token',
  UserRoles = 'x-user-roles'
}
