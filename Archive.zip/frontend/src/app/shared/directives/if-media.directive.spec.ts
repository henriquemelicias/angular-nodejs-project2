import { IfMediaDirective } from './if-media.directive';

describe('IfMediaDirective', () => {
  it('should create an instance', () => {
  });
});
