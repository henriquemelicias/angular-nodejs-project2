import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-info-task-info-dashboard',
  templateUrl: './project-task.component.html',
  styleUrls: [ './project-task.component.css']
})
export class ProjectTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
