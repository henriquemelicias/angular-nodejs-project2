import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-info-task-info-dashboard',
  templateUrl: './project-task.component.html',
  styleUrls: [ './project-task.component.css']
})
export class ProjectTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
