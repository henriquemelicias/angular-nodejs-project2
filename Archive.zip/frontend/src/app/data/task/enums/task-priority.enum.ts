export enum TaskPriorityEnum {
    BAIXA = "BAIXA",
    MEDIA = "MEDIA",
    ALTA = "ALTA",
    URGENTE = "URGENTE"
}