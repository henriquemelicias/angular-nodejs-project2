export interface TaskSchema {
    name: string;
    priority: string;
    percentage: number;
    //madeBy: User;
}