export enum AuthRolesEnum {
    USER = "USER",
    ADMIN = "ADMIN"
}