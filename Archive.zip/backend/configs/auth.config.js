module.exports = {
    secret: "mas-que-grande-segredo"
};