const TaskPriority = {
    BAIXA: "BAIXA",
    MEDIA: "MEDIA",
    ALTA: "ALTA",
    URGENTE: "URGENTE"
}

module.exports = {
    TaskPriority
}