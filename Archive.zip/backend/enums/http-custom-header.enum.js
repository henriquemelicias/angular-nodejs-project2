const HttpCustomHeaderEnum = {
  CsrfToken:'x-csrf-token',
  UserRoles:'x-user-roles'
}

module.exports = {
  HttpCustomHeaderEnum
}
