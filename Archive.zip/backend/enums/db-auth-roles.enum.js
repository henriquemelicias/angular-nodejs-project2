const AuthRoles = {
    USER: "USER",
    ADMIN: "ADMIN"
}

module.exports = {
    AuthRoles
}