const HttpCustomHeaderEnum = {
  CsrfToken:'X-Csrf-Token'
}

module.exports = {
  HttpCustomHeaderEnum
}
