export enum GenericMessage {
  UNEXPECTED_SERVER_RESPONSE = 'Unexpected server response: ',
  UNEXPECTED_UNHANDLED_ERROR = 'Unexpected unhandled error: '
}
