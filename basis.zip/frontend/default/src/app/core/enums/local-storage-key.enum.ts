export enum LocalStorageKeyEnum {
  AUTH_TOKEN = "auth-token",
  AUTH_USER = "auth-user",
  COLOR_THEME = "color-theme",
  REGISTER_FORM = "register-form-values"
}
