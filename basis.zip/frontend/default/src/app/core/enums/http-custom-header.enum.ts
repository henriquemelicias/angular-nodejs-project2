export enum HttpCustomHeaderEnum {
  CsrfToken = 'X-Csrf-Token'
}
