export interface UserSchema {
  _id: string;
  username: string;
  email?: string;
}
